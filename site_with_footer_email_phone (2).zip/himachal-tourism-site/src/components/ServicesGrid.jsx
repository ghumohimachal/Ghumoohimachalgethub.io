import React from 'react'

export default function ServicesGrid(){
  const services = [
    {title:'E-Services', desc:'License, permits, registrations', link:'/eservices'},
    {title:'Booking (HPTDC)', desc:'Official hotel bookings', link:'https://hptdc.in'},
    {title:'Events & Festivals', desc:'Fairs, dates & details', link:'/events'},
    {title:'How to Reach', desc:'Transport & maps', link:'/how-to-reach'}
  ]

  return (
    <section className="max-w-6xl mx-auto px-4 py-6">
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {services.map(s => (
          <a key={s.title} href={s.link} className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md">
            <h4 className="font-semibold">{s.title}</h4>
            <p className="text-sm text-slate-600 mt-1">{s.desc}</p>
          </a>
        ))}
      </div>
    </section>
  )
}
