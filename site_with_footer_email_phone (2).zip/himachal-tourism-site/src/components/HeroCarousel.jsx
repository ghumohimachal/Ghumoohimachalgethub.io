import React from 'react'

export default function HeroCarousel(){
  const slides = [
    {id:1, title:'Discover Shimla', caption:'Colonial charm & mountain views', img:'https://images.unsplash.com/photo-1508672019048-805c876b67e2?q=80&w=1600&auto=format&fit=crop&ixlib=rb-4.0.3&s=shimla'},
    {id:2, title:'Adventure in Manali', caption:'Trekking, skiing & paragliding', img:'https://images.unsplash.com/photo-1549880338-65ddcdfd017b?q=80&w=1600&auto=format&fit=crop&ixlib=rb-4.0.3&s=manali'},
    {id:3, title:'Culture of Dharamshala', caption:'Tibetan heritage and festivals', img:'https://images.unsplash.com/photo-1526481280698-3bfa7568f9d3?q=80&w=1600&auto=format&fit=crop&ixlib=rb-4.0.3&s=dharamshala'}
  ]

  return (
    <div className="relative overflow-hidden rounded-xl">
      <div className="flex w-full">
        {slides.map(s => (
          <div key={s.id} className="min-w-full h-64 sm:h-96 bg-cover bg-center" style={{backgroundImage:`url(${s.img})`}} aria-hidden="true">
            <div className="bg-black/30 h-full flex items-end p-6">
              <div className="text-white">
                <h2 className="text-xl sm:text-3xl font-bold">{s.title}</h2>
                <p className="text-sm sm:text-base">{s.caption}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
