import React from 'react'
import { Link, useLocation } from 'react-router-dom'
import { useTranslation } from 'react-i18next'

export default function Header(){
  const { t, i18n } = useTranslation()
  const loc = useLocation()

  return (
    <header className="bg-white shadow-md">
      <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-green-600 to-sky-500 flex items-center justify-center text-white font-bold">HP</div>
          <div>
            <div className="text-lg font-semibold">Himachal Explorer</div>
            <div className="text-xs text-slate-500">Discover. Plan. Visit.</div>
          </div>
        </Link>

        <nav className="flex gap-4 items-center">
          <Link to="/" className={loc.pathname==='/'? 'text-sky-600 font-medium' : 'text-slate-600'}>{t('plan_visit')}</Link>
          <Link to="/about" className="text-slate-600">About</Link>
          <Link to="/booking" className="px-3 py-1 bg-sky-600 text-white rounded-md">{t('book_now')}</Link>

          <select aria-label="language" value={i18n.language} onChange={(e)=>i18n.changeLanguage(e.target.value)} className="ml-2 border rounded-md px-2 py-1">
            <option value="en">EN</option>
            <option value="hi">हिंदी</option>
          </select>
        </nav>
      </div>
    </header>
  )
}
