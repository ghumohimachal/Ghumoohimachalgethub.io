import React from 'react'

export default function NoticeMarquee({notices=[]}){
  return (
    <div className="bg-yellow-50 border-t border-b py-2">
      <div className="max-w-6xl mx-auto px-4 flex items-center gap-4">
        <strong className="text-sm">Latest Notices:</strong>
        <div className="overflow-hidden whitespace-nowrap flex-1">
          <div className="animate-marquee inline-block">
            {notices.length ? notices.map(n => (
              <a key={n.id} href={n.link||'#'} className="mx-6 text-sm text-slate-700 hover:underline">{n.title} — {n.date}</a>
            )) : <span className="text-sm text-slate-600">No notices at the moment.</span>}
          </div>
        </div>
        <a href="/notices" className="text-sm text-sky-600">View all</a>
      </div>
    </div>
  )
}
