import React from 'react'

export default function EventsList({events=[]}){
  return (
    <section className="max-w-6xl mx-auto px-4 py-6">
      <h3 className="text-lg font-semibold mb-3">Upcoming Events</h3>
      <ul className="space-y-3">
        {events.length ? events.map(ev => (
          <li key={ev.id} className="bg-white p-3 rounded-md shadow-sm flex justify-between">
            <div>
              <div className="font-medium">{ev.title}</div>
              <div className="text-sm text-slate-600">{ev.place} — {ev.date}</div>
            </div>
            <a href={ev.link||'#'} className="text-sm text-sky-600 self-center">Details</a>
          </li>
        )) : <li className="text-slate-600">No upcoming events.</li>}
      </ul>
    </section>
  )
}
