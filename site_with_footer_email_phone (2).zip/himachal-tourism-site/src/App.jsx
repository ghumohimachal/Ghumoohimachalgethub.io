import React from 'react'
import { Routes, Route } from 'react-router-dom'
import Home from './pages/Home'
import Destination from './pages/Destination'
import Booking from './pages/Booking'
import About from './pages/About'
import Header from './components/Header'

export default function App(){
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <div className="flex-1">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/dest/:id" element={<Destination />} />
          <Route path="/booking" element={<Booking />} />
          <Route path="/about" element={<About />} />
        </Routes>
      </div>
      <footer className="bg-white border-t py-6 text-center text-sm text-slate-600">© {new Date().getFullYear()} Himachal Explorer  <p>Email: ghumohimachal033099@gmail.com</p>
  <p>Phone: 9805166019</p>
</footer>
    </div>
  )
}
