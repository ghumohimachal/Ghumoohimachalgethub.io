import i18n from 'i18next'
import { initReactI18next } from 'react-i18next'

const resources = {
  en: { translation: { "explore":"Explore Himachal Pradesh","search_placeholder":"Search places, activities or keywords","popular":"Popular Destinations","book_now":"Book Now","contact":"Contact","plan_visit":"Plan Your Visit" } },
  hi: { translation: { "explore":"हिमाचल प्रदेश की खोज करें","search_placeholder":"जगहें, गतिविधियाँ या कीवर्ड खोजें","popular":"लोकप्रिय गंतव्य","book_now":"अब बुक करें","contact":"संपर्क","plan_visit":"अपनी यात्रा योजना बनाएं" } }
}

i18n.use(initReactI18next).init({
  resources,
  lng: 'en',
  fallbackLng: 'en',
  interpolation: { escapeValue: false }
})

export default i18n
