import React, { useState } from 'react'

export default function Booking(){
  const [form, setForm] = useState({name:'', email:'', place:'', from:'', to:''})
  const [sent, setSent] = useState(false)

  function submit(e){
    e.preventDefault()
    const bookings = JSON.parse(localStorage.getItem('bookings')||'[]')
    bookings.push({...form, id:Date.now()})
    localStorage.setItem('bookings', JSON.stringify(bookings))
    setSent(true)
  }

  if(sent) return (
    <main className="max-w-2xl mx-auto p-6">
      <h2 className="text-xl font-semibold">Thanks — booking request saved</h2>
      <p className="mt-2 text-slate-600">This is a demo. To enable real bookings connect to a backend or third-party booking engine.</p>
    </main>
  )

  return (
    <main className="max-w-2xl mx-auto p-6 bg-white rounded-xl shadow-sm">
      <h2 className="text-xl font-semibold mb-4">Booking Request</h2>
      <form onSubmit={submit} className="space-y-3">
        <input required placeholder="Full name" value={form.name} onChange={e=>setForm({...form, name:e.target.value})} className="w-full border px-3 py-2 rounded-md" />
        <input required type="email" placeholder="Email" value={form.email} onChange={e=>setForm({...form, email:e.target.value})} className="w-full border px-3 py-2 rounded-md" />
        <input placeholder="Place (e.g. Manali)" value={form.place} onChange={e=>setForm({...form, place:e.target.value})} className="w-full border px-3 py-2 rounded-md" />
        <div className="grid grid-cols-2 gap-2">
          <input type="date" value={form.from} onChange={e=>setForm({...form, from:e.target.value})} className="w-full border px-3 py-2 rounded-md" />
          <input type="date" value={form.to} onChange={e=>setForm({...form, to:e.target.value})} className="w-full border px-3 py-2 rounded-md" />
        </div>
        <div className="flex justify-end">
          <button type="submit" className="px-4 py-2 bg-sky-600 text-white rounded-md">Send Request</button>
        </div>
      </form>
    </main>
  )
}
