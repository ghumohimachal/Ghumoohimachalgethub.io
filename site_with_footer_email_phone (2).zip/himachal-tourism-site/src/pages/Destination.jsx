import React from 'react'
import { useParams, Link } from 'react-router-dom'
import destinations from '../data/destinations.json'

export default function Destination(){
  const { id } = useParams()
  const dest = destinations.find(d=>String(d.id)===String(id))
  if(!dest) return (<main className="max-w-4xl mx-auto p-6">Destination not found</main>)

  return (
    <main className="max-w-4xl mx-auto p-6">
      <h1 className="text-2xl font-bold">{dest.name}</h1>
      <img src={dest.img} alt={dest.name} className="w-full h-64 object-cover mt-4 rounded-md" loading="lazy" decoding="async" />
      <p className="mt-4 text-slate-600">{dest.short} — detailed description goes here. Add transport, best time, and safety notes.</p>

      <div className="mt-6 flex gap-2">
        <Link to="/booking" className="px-4 py-2 bg-sky-600 text-white rounded-md">Start Booking</Link>
        <Link to="/" className="px-4 py-2 border rounded-md">Back</Link>
      </div>
    </main>
  )
}
