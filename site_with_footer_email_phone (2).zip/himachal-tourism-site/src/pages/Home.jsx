import React from 'react'
import HeroCarousel from '../components/HeroCarousel'
import NoticeMarquee from '../components/NoticeMarquee'
import ServicesGrid from '../components/ServicesGrid'
import EventsList from '../components/EventsList'
import destinations from '../data/destinations.json'
import notices from '../data/notices.json'
import events from '../data/events.json'
import { Link } from 'react-router-dom'

export default function Home(){
  return (
    <main>
      <NoticeMarquee notices={notices} />
      <div className="max-w-6xl mx-auto px-4 py-6">
        <HeroCarousel />
        <ServicesGrid />
        <section className="mt-8">
          <h2 className="text-xl font-semibold mb-4">Popular Destinations</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {destinations.map(d => (
              <article key={d.id} className="bg-white rounded-xl shadow-sm overflow-hidden">
                <img src={d.img_sm} srcSet={`${d.img_sm} 800w, ${d.img} 1600w`} sizes="(max-width: 640px) 800px, 1600px" loading="lazy" decoding="async" alt={d.name} className="w-full h-44 object-cover" />
                <div className="p-4">
                  <h3 className="font-semibold text-lg">{d.name}</h3>
                  <p className="text-sm text-slate-600">{d.short}</p>
                  <div className="mt-3 flex items-center justify-between">
                    <div className="text-xs text-slate-500">Region: {d.region}</div>
                    <div className="flex gap-2">
                      <Link to={`/dest/${d.id}`} className="px-3 py-1 text-sm border rounded-md">Details</Link>
                      <Link to="/booking" className="px-3 py-1 text-sm bg-sky-600 text-white rounded-md">Book Now</Link>
                    </div>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </section>

        <EventsList events={events} />
      </div>
    </main>
  )
}
