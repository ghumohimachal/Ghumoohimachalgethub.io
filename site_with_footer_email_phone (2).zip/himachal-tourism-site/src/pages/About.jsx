import React from 'react'

export default function About(){
  return (
    <main className="max-w-4xl mx-auto p-6">
      <h1 className="text-2xl font-bold">About Himachal Explorer</h1>
      <p className="mt-4 text-slate-600">This is a demo tourism website scaffold inspired by official state portals. Replace content with official data and connect to booking providers for production.</p>
    </main>
  )
}
