# Himachal Explorer — Demo (HP Tourism style)

Quick start:
1. npm install
2. npm run dev
3. Open http://localhost:5173

This is a demo scaffold inspired by the Himachal Pradesh tourism portal.
Images use Unsplash links. To host images locally, replace URLs in src/data/destinations.json and add files to public/images/.
